// Strips files the Sites uploader refuses (hidden files and source maps)
// from the client assets, so `deploy.json` can point straight at dist/.
// The worker bundle keeps its source map: wrangler uploads it for telemetry.
import { readdirSync, rmSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

function clean(dir) {
  for (const name of readdirSync(dir)) {
    const path = join(dir, name)
    if (name.startsWith('.') || name.endsWith('.map')) {
      rmSync(path, { recursive: true, force: true })
      continue
    }
    if (statSync(path).isDirectory()) clean(path)
  }
}

// fileURLToPath, not URL.pathname: on Windows the pathname is `/C:/...`,
// which path.join resolves as `<drive>:\C:\...`.
clean(fileURLToPath(new URL('../dist/client', import.meta.url)))
