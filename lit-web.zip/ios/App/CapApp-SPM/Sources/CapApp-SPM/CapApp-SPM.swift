public let isCapacitorApp = true
